package model.bean;

public class ListaPalavraChava {


    public ListaPalavraChava(){
    }

}
