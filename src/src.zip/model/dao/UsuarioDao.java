package model.dao;

public class UsuarioDao {
}
