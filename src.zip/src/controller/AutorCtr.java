package controller;

import boundery.TelaCadAutores;
import model.bean.Autor;
import model.dao.AutorDao;

import java.util.ArrayList;
import java.util.List;

public class AutorCtr {

    AutorDao autorDao = new AutorDao();
    TelaCadAutores tela = new TelaCadAutores();

    public Autor pesqCtlrAutor(String nome){
        Autor autor = new Autor();

        //Dao de pesquisa
        //autor = autorDao.PesqAutor(nome);
        tela.setTelaAutor(autor);
        System.out.println("Funcionou Controle Autor Pesquisar");
        return autor;
    }

    public void salvaAutor(Autor autor){

        //Classe dao de salvar autor
        //a classe DAO deve retornar o objeto autor com o ID incluso
        //autor = autorDao.salvarNovoAutor(autor);
        tela.setTelaAutor(autor);
        System.out.println("Funcionou Controle Autor Salvar");
        System.out.println(autor);
    }

    public void editaAutor(Autor autor){
        //Classe Dao para editar existente
        //autor = autorDao.editaAutor(autor);
        tela.setTelaAutor(autor);
        System.out.println("Funcionou Controle Autor editar");
        System.out.println(autor);
    }

    public void limpaAutor(){
        tela.restartCrud();
        System.out.println("Limpeza autor OK");
    }
}
