package controller;

public class GeneroCtr {
}
