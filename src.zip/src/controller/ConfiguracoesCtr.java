package controller;

public class ConfiguracoesCtr {
}
