package controller;

import model.bean.Usuario;
import principal.MainBiblioteca;

public class LoginCtr {

    Boolean validacao = false;
    //UsuarioDao usuarioDao = new UsuarioDao();
    BtnLateralControler btnLateralControler = new BtnLateralControler();

    public void checaLoginFixo(Usuario usuario){
        String pass, user;
        pass = usuario.getSenha();
        user = usuario.getUsuario();

        if(user != "master" || pass != "senhaMaster"){
            validacao = true;
        }


        if(validacao == true){
            MainBiblioteca.scnPrincipal.setRoot(btnLateralControler.crudCliente());
        }else{
            System.out.println("PROIBIDA A ENTRADA");
        }
    }

    public void checaLoginDAO(Usuario usuario){

        //Realiza busca na classe dao enviando o user
        //validacao = usuarioDao.pesqValida(usuario);
        if(validacao == true){
            MainBiblioteca.scnPrincipal.setRoot(btnLateralControler.crudCliente());
        }else{
            System.out.println("PROIBIDA A ENTRADA");
        }
    }
}
