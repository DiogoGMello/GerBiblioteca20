package controller;

import boundery.TelaCadFuncionario;
import model.bean.Funcionario;

public class FuncionariosCtr {
    TelaCadFuncionario telaCadFuncionario = new TelaCadFuncionario();

    public void pesqCtrlFuncionario(Funcionario funcionario){
        if(funcionario.getNome() == ""){
            //Classe DAO para pesquisa por nome
            //cliente = clienteDao.buscaClienteNome(cliente.getNome());
            System.out.println("Pesquisa cliente pelo nome " + funcionario.getNome());
            telaCadFuncionario.setTelaFuncionario(funcionario);
        }else{
            //Classe DAO para pesquisa por nome
            //cliente = clienteDao.buscaClienteNome(Integer.toString(cliente.getCpf()));
            System.out.println("Pesquisa cliente pelo CPF " + funcionario.getCpf());
            telaCadFuncionario.setTelaFuncionario(funcionario);
        }
    }

    public void salvaFuncionario(Funcionario funcionario){
        //classe dao para salvar funcionario novo
        //funcionario = funcionarioDao.salvaClienteNovo(cliente);
        System.out.println("Salva o funcionario corretamente");
        telaCadFuncionario.setTelaFuncionario(funcionario);
    }

    public void editaFuncionario(Funcionario funcionario){
        //Salva o funcionario de acordo com o id
        //funcionario = funcionarioDao.editaFuncionario(funcionario);
        System.out.println("Edita funcionario corretamente");
        telaCadFuncionario.setTelaFuncionario(funcionario);
    }

    public void limpaFuncionario(){
        System.out.println("Limpa funcionario ok");
        telaCadFuncionario.restartCrudFuncionario();
    }
}
