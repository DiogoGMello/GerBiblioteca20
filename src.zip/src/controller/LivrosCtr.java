package controller;

import boundery.TelaCadLivro;
import model.bean.Cliente;
import model.bean.Livro;
import model.dao.LivroDao;

import java.util.ArrayList;
import java.util.List;

public class LivrosCtr {

    TelaCadLivro tela = new TelaCadLivro();

    public Livro pesqCtrlLivro(Livro livro){

        if(livro.getTitulo() != null || livro.getTitulo() != ""){
            //Classe dao para buscar por titulo
            System.out.println("Busca por titulo " + livro.getTitulo());
            return livro;
        }else {
            //Classe dao para buscar por subtitulo

            System.out.println("Busca por Subtitulo " + livro.getSubTitulo());
            return livro;
        }
    }

    public void salvaLivro(Livro livro){
        //Classe dao de salvar livro
        //a classe DAO deve retornar o objeto livro com o ID incluso
        //livro = livroDao.salvarNovoLivro(livro);
        tela.setTelaLivro(livro);
        System.out.println("Funcionou Controle Livro Salvar");
        System.out.println(livro);
    }

    public void editaLivro(Livro livro){
        //Classe Dao para livro existente
        //livro = autorDao.editaLivro(livro);
        tela.setTelaLivro(livro);
        System.out.println("Funcionou Controle livro editar");
        System.out.println(livro);
    }

    public void limpaLivro(){
        tela.restartCrudLivro();
        System.out.println("Limpeza livro OK");
    }
}
