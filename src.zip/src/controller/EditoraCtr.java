package controller;

import boundery.TelaCadEditora;
import model.bean.Editora;
import model.dao.EditoraDao;

public class EditoraCtr {
    EditoraDao editoraDao = new EditoraDao();
    TelaCadEditora tela = new TelaCadEditora();

    public Editora pesqCtrlEditora(String nome){
        Editora editora = new Editora();

        //Classe dao de pesquisa de editora
        //editora = editoraDao.pesquisaEditora(nome)
        tela.setTelaEditora(editora);
        System.out.println("Pesquisa Editora Ok");
        return editora;
    }

    public void salvaEditora(Editora editora){
        //editora = tela.coletaEditora();
        //classe dao
        tela.setTelaEditora(editora);
        System.out.println("Salva Editora ok");
        System.out.println(editora);

    }

    public void editaEditora(Editora editora){
        //classe dao para editar
        tela.setTelaEditora(editora);
        System.out.println("Alterar Editora ok");
        System.out.println(editora);
    }

    public void limpaEditora(){
        tela.restartCrudEditora();
        System.out.println("Limpeza de tela OK");
    }
}
