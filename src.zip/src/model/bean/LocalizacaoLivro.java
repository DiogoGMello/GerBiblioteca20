package model.bean;

public class LocalizacaoLivro {


    public LocalizacaoLivro(){
    }

}
