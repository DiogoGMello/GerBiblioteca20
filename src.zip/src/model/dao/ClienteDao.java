package model.dao;

import connection.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import model.bean.Cliente;

public class ClienteDao {

    private Connection con = null;

//    public ClienteDao(){
//        con = ConnectionFactory.getConnection();
//    }

    //ir� inserir um novo campo no banco de dados
    public boolean salvarClienteBD(Cliente cliente){

        String sql = "INSERT INTO cliente () VALUES ()";

        PreparedStatement stmt = null;

        try{
            stmt = con.prepareStatement(sql);

//            stmt.setString(1, cliente.());
//            stmt.setString(2, cliente.());
//            stmt.setString(3, cliente.());

            stmt.executeUpdate();

            return true;

        }catch (SQLException ex){

            System.err.println("Erro: " + ex);

            return false;
        }finally{

            //ConnectionFactory.closeConnection(con, stmt);

        }
    }

    //Ir� atualizar o registro do cliente
    public boolean alterarClienteBD(Cliente cliente){

        String sql = "UPDATE cliente SET nome = ?, endereco = ?, telefone = ? WHERE cliente_ID = ? ? ? ? ?";

        try{
            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setInt(1, cliente.getIdCliente());
            stmt.setInt(2, cliente.getCpf());
            stmt.setString(3, cliente.getNome());
            stmt.setString(4, cliente.getEndereco());
            stmt.setInt(5, cliente.getNumeroEndereco());
            stmt.setString(6, cliente.getBairro());
            stmt.setInt(7, cliente.getCep());

            return true;

        }catch(SQLException ex){

            System.err.println("Error: "+ex);
            return false;

        }finally{

            //ConnectionFactory.closeConnection(con, stmt);
        }
    }

    //Buscar todos os registros de cliente da tabela
    public List<Cliente> encontrarClienteBDTodos(){

        String sql = "SELECT * FROM cliente";

        PreparedStatement stmt = null;
        ResultSet rs = null;

        List<Cliente> cliente = new ArrayList<>();

        return cliente;
    }

    public Cliente encontrarClienteID(int id) throws ParseException {
        String sql = "SELECT * FROM cliente ";

        PreparedStatement stmt = null;
        ResultSet rs = null;

        Cliente cliente = new Cliente();
        return cliente;
    }
}

